import pygame as pg
from random import randrange
import sys
from pygame import font, gfxdraw
import math
import os
from collections import deque

# Inicialização do Pygame com verificação
try:
    pg.init()
    if pg.get_init() == False:
        raise Exception("Pygame não inicializou corretamente")
    
    if not font.get_init():
        font.init()
        if not font.get_init():
            raise Exception("Fonte não inicializou corretamente")
except Exception as e:
    print(f"Erro na inicialização: {e}")
    sys.exit(1)

# Constantes
GAME_WIDTH = 600
GAME_HEIGHT = 600
SCORE_HEIGHT = 50
WINDOW_SIZE = (GAME_WIDTH, GAME_HEIGHT + SCORE_HEIGHT)
TILE_SIZE = 20
RANGE = (TILE_SIZE // 2, GAME_HEIGHT - TILE_SIZE // 2, TILE_SIZE)

# Fontes
try:
    GAME_FONT = pg.font.SysFont('arial', 20)
    GAME_OVER_FONT = pg.font.SysFont('arial', 36)
    CONTROLS_FONT = pg.font.SysFont('arial', 16)  # Nova fonte para controles
    if not GAME_FONT or not GAME_OVER_FONT or not CONTROLS_FONT:
        raise Exception("Fontes não carregadas corretamente")
except Exception as e:
    print(f"Erro ao carregar fontes: {e}")
    sys.exit(1)

# Cores
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
DARK_GREEN = (0, 200, 0)
BLUE = (0, 0, 255)
GRID_COLOR = (50, 50, 50)
SCORE_BG = (30, 30, 30)
FOOD_COLORS = [(255, 0, 0), (255, 50, 50)]
YELLOW = (255, 255, 0)

class SnakeGame:
    def __init__(self):
        try:
            self.screen = pg.display.set_mode(WINDOW_SIZE)
            if not self.screen:
                raise Exception("Tela não criada corretamente")
            pg.display.set_caption('Snake Game')
            self.clock = pg.time.Clock()
            self.game_surface = pg.Surface((GAME_WIDTH, GAME_HEIGHT))
            self.score_surface = pg.Surface((GAME_WIDTH, SCORE_HEIGHT))
            if not self.game_surface or not self.score_surface:
                raise Exception("Superfícies não criadas corretamente")
            self.movement_queue = deque(maxlen=2)
            self.last_movement_time = 0
            self.movement_delay = 50
            self.paused = False  # Estado de pausa
            self.show_controls = False  # Estado de exibição dos controles
            self.debug_mode = False  # Modo debug
            self.reset_game()
        except Exception as e:
            print(f"Erro na inicialização do jogo: {e}")
            sys.exit(1)

    def reset_game(self):
        try:
            self.get_random_position = lambda: [randrange(*RANGE), randrange(*RANGE)]
            self.snake = pg.rect.Rect([0, 0, TILE_SIZE - 2, TILE_SIZE - 2])
            if not self.snake:
                raise Exception("Snake não criada corretamente")
            self.snake.center = self.get_random_position()
            self.length = 1
            self.segments = [self.snake.copy()]
            self.snake_dir = (0, 0)
            self.current_direction = (0, 0)
            self.time = pg.time.get_ticks()
            self.time_step = 100
            self.initial_time_step = 100  # Guarda a velocidade inicial
            self.food = self.snake.copy()
            self.food.center = self.get_random_position()
            self.score = 0
            self.high_score = self.load_high_score()
            self.game_over = False
            self.dirs = {pg.K_w: 1, pg.K_s: 1, pg.K_a: 1, pg.K_d: 1}
            self.food_animation = 0
            self.movement_queue.clear()
        except Exception as e:
            print(f"Erro ao resetar o jogo: {e}")
            sys.exit(1)

    def load_high_score(self):
        """Carrega a pontuação máxima do arquivo"""
        try:
            if not os.path.exists('high_score.txt'):
                return 0
            with open('high_score.txt', 'r') as f:
                score = f.read().strip()
                if not score.isdigit():
                    return 0
                return int(score)
        except Exception as e:
            print(f"Erro ao carregar high score: {e}")
            return 0
            
    def save_high_score(self):
        """Salva a pontuação máxima no arquivo"""
        try:
            with open('high_score.txt', 'w') as f:
                f.write(str(max(0, self.high_score)))
        except Exception as e:
            print(f"Erro ao salvar high score: {e}")

    def is_opposite_direction(self, dir1, dir2):
        """Verifica se duas direções são opostas"""
        return (dir1[0] == -dir2[0] and dir1[1] == -dir2[1])

    def is_valid_movement(self, new_direction):
        """Verifica se o movimento é válido baseado na direção atual"""
        if not self.current_direction[0] and not self.current_direction[1]:
            return True
        return not self.is_opposite_direction(new_direction, self.current_direction)

    def draw_rounded_rect(self, surface, rect, color, radius=8):
        """Desenha um retângulo com cantos arredondados"""
        try:
            if not surface or not rect:
                return
            
            x, y, width, height = rect
            if width <= 0 or height <= 0:
                return
                
            radius = min(radius, width // 2, height // 2)
            
            gfxdraw.aacircle(surface, x + radius, y + radius, radius, color)
            gfxdraw.aacircle(surface, x + width - radius - 1, y + radius, radius, color)
            gfxdraw.aacircle(surface, x + radius, y + height - radius - 1, radius, color)
            gfxdraw.aacircle(surface, x + width - radius - 1, y + height - radius - 1, radius, color)
            
            gfxdraw.filled_circle(surface, x + radius, y + radius, radius, color)
            gfxdraw.filled_circle(surface, x + width - radius - 1, y + radius, radius, color)
            gfxdraw.filled_circle(surface, x + radius, y + height - radius - 1, radius, color)
            gfxdraw.filled_circle(surface, x + width - radius - 1, y + height - radius - 1, radius, color)
            
            pg.draw.rect(surface, color, (x + radius, y, width - radius * 2, height))
            pg.draw.rect(surface, color, (x, y + radius, width, height - radius * 2))
        except Exception as e:
            print(f"Erro ao desenhar retângulo arredondado: {e}")

    def draw_grid(self):
        """Desenha a grade do jogo"""
        try:
            if not self.game_surface:
                return
                
            for x in range(0, GAME_WIDTH, TILE_SIZE):
                pg.draw.line(self.game_surface, GRID_COLOR, (x, 0), (x, GAME_HEIGHT))
            for y in range(0, GAME_HEIGHT, TILE_SIZE):
                pg.draw.line(self.game_surface, GRID_COLOR, (0, y), (GAME_WIDTH, y))
        except Exception as e:
            print(f"Erro ao desenhar grid: {e}")

    def draw_food(self, surface, rect):
        """Desenha a comida com efeito de brilho"""
        try:
            if not surface or not rect:
                return
                
            self.food_animation = (self.food_animation + 0.1) % (2 * math.pi)
            glow_size = max(0, int(math.sin(self.food_animation) * 2) + TILE_SIZE)
            
            glow_surf = pg.Surface((glow_size * 2, glow_size * 2), pg.SRCALPHA)
            if not glow_surf:
                return
                
            pg.draw.circle(glow_surf, (*RED[:3], 100), (glow_size, glow_size), glow_size // 2)
            surface.blit(glow_surf, (rect.centerx - glow_size, rect.centery - glow_size))
            
            self.draw_rounded_rect(surface, rect, RED, radius=4)
        except Exception as e:
            print(f"Erro ao desenhar comida: {e}")

    def draw_score_panel(self):
        """Desenha o painel de pontuação"""
        try:
            if not self.score_surface or not GAME_FONT:
                return
                
            self.score_surface.fill(SCORE_BG)
            score_text = GAME_FONT.render(f'Score: {self.score}', True, WHITE)
            high_score_text = GAME_FONT.render(f'High Score: {self.high_score}', True, WHITE)
            
            if not score_text or not high_score_text:
                return
            
            score_x = max(0, (GAME_WIDTH - score_text.get_width()) // 2 - 100)
            high_score_x = max(0, (GAME_WIDTH - high_score_text.get_width()) // 2 + 100)
            y = max(0, (SCORE_HEIGHT - score_text.get_height()) // 2)
            
            self.score_surface.blit(score_text, (score_x, y))
            self.score_surface.blit(high_score_text, (high_score_x, y))
        except Exception as e:
            print(f"Erro ao desenhar painel de pontuação: {e}")

    def check_collision(self):
        """Verifica colisões da cobra"""
        try:
            if not self.snake or not self.segments:
                return
                
            border_collision = (
                self.snake.left < -TILE_SIZE or 
                self.snake.right > GAME_WIDTH + TILE_SIZE or 
                self.snake.top < -TILE_SIZE or 
                self.snake.bottom > GAME_HEIGHT + TILE_SIZE
            )
            
            self_eating = pg.Rect.collidelist(self.snake, self.segments[:-1]) != -1
            
            if border_collision or self_eating:
                if self.score > self.high_score:
                    self.high_score = self.score
                    self.save_high_score()
                self.game_over = True
        except Exception as e:
            print(f"Erro ao verificar colisão: {e}")

    def draw_controls(self):
        try:
            controls = [
                "Controles:",
                "WASD / Setas - Movimento",
                "P - Pausar/Continuar",
                "H - Mostrar/Esconder Controles",
                "R - Reiniciar (quando Game Over)",
                "D - Modo Debug",
                "+ - Aumentar Velocidade",
                "- - Diminuir Velocidade",
                "ESC - Sair"
            ]
            
            overlay = pg.Surface((GAME_WIDTH, GAME_HEIGHT), pg.SRCALPHA)
            overlay.fill((0, 0, 0, 180))
            self.game_surface.blit(overlay, (0, 0))
            
            y_pos = 50
            for text in controls:
                control_text = CONTROLS_FONT.render(text, True, WHITE)
                text_rect = control_text.get_rect(center=(GAME_WIDTH//2, y_pos))
                self.game_surface.blit(control_text, text_rect)
                y_pos += 30
        except Exception as e:
            print(f"Erro ao desenhar controles: {e}")

    def handle_input(self):
        try:
            current_time = pg.time.get_ticks()
            
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    self.save_high_score()
                    pg.quit()
                    sys.exit()
                    
                if event.type == pg.KEYDOWN:
                    # Controles globais (funcionam mesmo em pause)
                    if event.key == pg.K_p:  # Pausa
                        self.paused = not self.paused
                    elif event.key == pg.K_h:  # Mostrar/esconder controles
                        self.show_controls = not self.show_controls
                    elif event.key == pg.K_d:  # Modo debug
                        self.debug_mode = not self.debug_mode
                    elif event.key == pg.K_ESCAPE:  # Sair
                        self.save_high_score()
                        pg.quit()
                        sys.exit()
                    elif event.key == pg.K_EQUALS:  # Aumentar velocidade
                        self.time_step = max(50, self.time_step - 10)
                    elif event.key == pg.K_MINUS:  # Diminuir velocidade
                        self.time_step = min(200, self.time_step + 10)
                    
                    # Controles que só funcionam quando não está pausado
                    if not self.paused:
                        if event.key == pg.K_r and self.game_over:
                            self.reset_game()
                            
                        if not self.game_over:
                            new_dir = None
                            # Suporte para WASD e setas
                            if event.key in [pg.K_w, pg.K_UP] and self.dirs.get(pg.K_w, 0):
                                new_dir = (0, -TILE_SIZE)
                            elif event.key in [pg.K_s, pg.K_DOWN] and self.dirs.get(pg.K_s, 0):
                                new_dir = (0, TILE_SIZE)
                            elif event.key in [pg.K_a, pg.K_LEFT] and self.dirs.get(pg.K_a, 0):
                                new_dir = (-TILE_SIZE, 0)
                            elif event.key in [pg.K_d, pg.K_RIGHT] and self.dirs.get(pg.K_d, 0):
                                new_dir = (TILE_SIZE, 0)

                            if new_dir and (not self.movement_queue or 
                                current_time - self.last_movement_time >= self.movement_delay):
                                
                                if not self.movement_queue:
                                    if self.is_valid_movement(new_dir):
                                        self.movement_queue.append(new_dir)
                                        self.last_movement_time = current_time
                                elif not self.is_opposite_direction(new_dir, self.movement_queue[-1]):
                                    self.movement_queue.append(new_dir)
                                    self.last_movement_time = current_time
                            
        except Exception as e:
            print(f"Erro ao processar entrada: {e}")

    def draw(self):
        try:
            if not all([self.game_surface, self.screen, self.score_surface]):
                return
                
            # Limpa as superfícies
            self.game_surface.fill(BLACK)
            self.draw_grid()
            
            # Desenha a comida
            if self.food:
                self.draw_food(self.game_surface, self.food)
            
            # Desenha a cobra
            if self.segments:
                for i, segment in enumerate(self.segments):
                    gradient_factor = min(1, i / max(self.length, 1))
                    color = (
                        0,
                        max(0, min(255, int(255 - (gradient_factor * 100)))),
                        0
                    )
                    self.draw_rounded_rect(self.game_surface, segment, color, radius=4)
            
            # Desenha informações de debug
            if self.debug_mode:
                debug_info = [
                    f"FPS: {int(self.clock.get_fps())}",
                    f"Velocidade: {self.time_step}ms",
                    f"Tamanho: {self.length}",
                    f"Direção: {self.current_direction}",
                    f"Posição: {self.snake.center if self.snake else 'N/A'}"
                ]
                y = 10
                for info in debug_info:
                    debug_text = CONTROLS_FONT.render(info, True, YELLOW)
                    self.game_surface.blit(debug_text, (10, y))
                    y += 20
            
            # Desenha o painel de pontuação
            self.draw_score_panel()
            
            # Desenha estado de pausa
            if self.paused:
                overlay = pg.Surface((GAME_WIDTH, GAME_HEIGHT), pg.SRCALPHA)
                overlay.fill((0, 0, 0, 128))
                self.game_surface.blit(overlay, (0, 0))
                pause_text = GAME_OVER_FONT.render('PAUSADO', True, WHITE)
                text_rect = pause_text.get_rect(center=(GAME_WIDTH//2, GAME_HEIGHT//2))
                self.game_surface.blit(pause_text, text_rect)
            
            # Desenha controles se ativado
            if self.show_controls:
                self.draw_controls()
            
            # Game Over
            if self.game_over:
                overlay = pg.Surface((GAME_WIDTH, GAME_HEIGHT), pg.SRCALPHA)
                overlay.fill((0, 0, 0, 128))
                self.game_surface.blit(overlay, (0, 0))
                
                game_over_text = GAME_OVER_FONT.render('GAME OVER!', True, WHITE)
                restart_text = GAME_FONT.render('Press R to Restart', True, WHITE)
                
                text_rect = game_over_text.get_rect(center=(GAME_WIDTH//2, GAME_HEIGHT//2))
                restart_rect = restart_text.get_rect(center=(GAME_WIDTH//2, GAME_HEIGHT//2 + 40))
                
                self.game_surface.blit(game_over_text, text_rect)
                self.game_surface.blit(restart_text, restart_rect)
            
            # Combina as superfícies na tela principal
            self.screen.blit(self.game_surface, (0, 0))
            self.screen.blit(self.score_surface, (0, GAME_HEIGHT))
            
            try:
                pg.display.flip()
            except pg.error:
                print("Erro ao atualizar a tela")
        except Exception as e:
            print(f"Erro ao desenhar: {e}")

    def update(self):
        try:
            if not self.game_over and self.snake and self.food and not self.paused:
                if self.snake.center == self.food.center:
                    self.food.center = self.get_random_position()
                    max_attempts = 100
                    attempts = 0
                    while pg.Rect.collidelist(self.food, self.segments) != -1:
                        if attempts >= max_attempts:
                            break
                        self.food.center = self.get_random_position()
                        attempts += 1
                    
                    self.length = min(self.length + 1, 1000)
                    self.score += 10
                    if self.score % 50 == 0:
                        self.time_step = max(50, self.time_step - 10)

                time_now = pg.time.get_ticks()
                if time_now - self.time >= self.time_step:
                    self.time = time_now
                    
                    if self.movement_queue:
                        next_dir = self.movement_queue.popleft()
                        if self.is_valid_movement(next_dir) or not self.current_direction[0] and not self.current_direction[1]:
                            self.snake_dir = next_dir
                            self.current_direction = next_dir
                    
                    if self.snake_dir != (0, 0):
                        self.snake.move_ip(self.snake_dir)
                        self.segments.append(self.snake.copy())
                        self.segments = self.segments[-self.length:]
                        
                self.check_collision()
        except Exception as e:
            print(f"Erro ao atualizar jogo: {e}")
            
    def draw_grid(self):
        try:
            if not self.game_surface:
                return
                
            for x in range(0, GAME_WIDTH, TILE_SIZE):
                pg.draw.line(self.game_surface, GRID_COLOR, (x, 0), (x, GAME_HEIGHT))
            for y in range(0, GAME_HEIGHT, TILE_SIZE):
                pg.draw.line(self.game_surface, GRID_COLOR, (0, y), (GAME_WIDTH, y))
        except Exception as e:
            print(f"Erro ao desenhar grid: {e}")
            
    def draw_score_panel(self):
        try:
            if not self.score_surface or not GAME_FONT:
                return
                
            self.score_surface.fill(SCORE_BG)
            score_text = GAME_FONT.render(f'Score: {self.score}', True, WHITE)
            high_score_text = GAME_FONT.render(f'High Score: {self.high_score}', True, WHITE)
            
            if not score_text or not high_score_text:
                return
            
            score_x = max(0, (GAME_WIDTH - score_text.get_width()) // 2 - 100)
            high_score_x = max(0, (GAME_WIDTH - high_score_text.get_width()) // 2 + 100)
            y = max(0, (SCORE_HEIGHT - score_text.get_height()) // 2)
            
            self.score_surface.blit(score_text, (score_x, y))
            self.score_surface.blit(high_score_text, (high_score_x, y))
        except Exception as e:
            print(f"Erro ao desenhar painel de pontuação: {e}")
            
    def draw(self):
        try:
            if not all([self.game_surface, self.screen, self.score_surface]):
                return
                
            # Limpa as superfícies
            self.game_surface.fill(BLACK)
            self.draw_grid()
            
            # Desenha a comida
            if self.food:
                self.draw_food(self.game_surface, self.food)
            
            # Desenha a cobra
            if self.segments:
                for i, segment in enumerate(self.segments):
                    gradient_factor = min(1, i / max(self.length, 1))
                    color = (
                        0,
                        max(0, min(255, int(255 - (gradient_factor * 100)))),
                        0
                    )
                    self.draw_rounded_rect(self.game_surface, segment, color, radius=4)
            
            # Desenha o painel de pontuação
            self.draw_score_panel()
            
            # Game Over
            if self.game_over and GAME_OVER_FONT and GAME_FONT:
                overlay = pg.Surface((GAME_WIDTH, GAME_HEIGHT), pg.SRCALPHA)
                if overlay:
                    overlay.fill((0, 0, 0, 128))
                    self.game_surface.blit(overlay, (0, 0))
                    
                    game_over_text = GAME_OVER_FONT.render('GAME OVER!', True, WHITE)
                    restart_text = GAME_FONT.render('Press R to Restart', True, WHITE)
                    
                    if game_over_text and restart_text:
                        text_rect = game_over_text.get_rect(center=(GAME_WIDTH//2, GAME_HEIGHT//2))
                        restart_rect = restart_text.get_rect(center=(GAME_WIDTH//2, GAME_HEIGHT//2 + 40))
                        
                        self.game_surface.blit(game_over_text, text_rect)
                        self.game_surface.blit(restart_text, restart_rect)
            
            # Combina as superfícies na tela principal
            self.screen.blit(self.game_surface, (0, 0))
            self.screen.blit(self.score_surface, (0, GAME_HEIGHT))
            
            try:
                pg.display.flip()
            except pg.error:
                print("Erro ao atualizar a tela")
        except Exception as e:
            print(f"Erro ao desenhar: {e}")
        
    def run(self):
        try:
            while True:
                try:
                    self.handle_input()
                    self.update()
                    self.draw()
                    
                    # Limita FPS com verificação de erro
                    try:
                        self.clock.tick(60)
                    except pg.error:
                        print("Erro ao controlar FPS")
                        
                except Exception as e:
                    print(f"Erro no loop principal: {e}")
                    # Tenta recuperar o jogo
                    self.reset_game()
        except KeyboardInterrupt:
            print("\nJogo encerrado pelo usuário")
        except Exception as e:
            print(f"Erro fatal: {e}")
        finally:
            try:
                self.save_high_score()  # Salva score antes de sair
                pg.quit()
            except:
                pass
            sys.exit()

if __name__ == '__main__':
    try:
        game = SnakeGame()
        game.run()
    except Exception as e:
        print(f"Erro ao iniciar o jogo: {e}")
        sys.exit(1)